from dotenv import load_dotenv
print(f"loading env variable from .env")
load_dotenv()