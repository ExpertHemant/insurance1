#!bin/sh
nohup airflow scheduler &
airflow webserver